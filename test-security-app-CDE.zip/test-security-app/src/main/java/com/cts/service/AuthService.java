package com.cts.service;

import com.cts.dtos.LoginDto;

public interface AuthService {

	String login(LoginDto loginDto);
}
