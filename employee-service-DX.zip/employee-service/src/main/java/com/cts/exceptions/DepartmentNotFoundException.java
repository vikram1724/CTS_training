package com.cts.exceptions;

public class DepartmentNotFoundException extends RuntimeException {

	public DepartmentNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DepartmentNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
