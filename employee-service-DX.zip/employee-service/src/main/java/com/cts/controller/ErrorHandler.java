package com.cts.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cts.exceptions.DepartmentNotFoundException;
import com.cts.exceptions.EmployeeNotFoundException;

@ControllerAdvice
public class ErrorHandler {

	@ExceptionHandler(EmployeeNotFoundException.class)
	public ResponseEntity<String> handleEmployeeNotFound(EmployeeNotFoundException ex) {
		
		ResponseEntity<String> re=new ResponseEntity<String>(ex.getMessage(),HttpStatus.NOT_FOUND);
		return re;	
	}
	
	@ExceptionHandler(DepartmentNotFoundException.class)
	public ResponseEntity<String> handleDepartmentNoFound(DepartmentNotFoundException ex) {
		return new ResponseEntity<>(ex.getMessage(),HttpStatus.NOT_FOUND);
				
	}
	
	
}
