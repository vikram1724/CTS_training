package com.cts.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.stereotype.Service;

import com.cts.exceptions.DepartmentNotFoundException;
import com.cts.model.Department;
import com.cts.repository.DepartmentRepository;
@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	
	private DepartmentRepository departmentRepository;
	
	@Override
	public List<Department> getDepartments() {
		// TODO Auto-generated method stub
		return departmentRepository.findAll();
	}

	@Override
	public Department getById(int id) {
		// TODO Auto-generated method stub
		return departmentRepository.findById(id)
				.orElseThrow(()->new DepartmentNotFoundException("Department with id "+id+" not found"));
	}

	@Override
	public String addDepartment(Department department) {
		departmentRepository.save(department);
		return "Department with id"+department.getDeptId()+" added successfully";
	}

	@Override
	public String updateDepartment(int id, Department department) {
		Optional<Department> optDept=departmentRepository.findById(id);
		if(!optDept.isPresent()) {
			throw new DepartmentNotFoundException("Department with Id "+id+" Not found");
		}
		department.setDeptId(id);
		departmentRepository.save(department);
		return "Department with id"+id+" updated successfully";
	}

	@Override
	public String deleteDepartment(int id) {
		departmentRepository.deleteById(id);
		return "Department with id"+id+" deleted successfully";
	}

}
