package com.cts.service;

import java.util.List;

import com.cts.model.Department;

public interface DepartmentService {

	List<Department> getDepartments();
	Department getById(int id);
	String addDepartment(Department department);
	String updateDepartment(int id,Department department);
	String deleteDepartment(int id);
}
