package com.cts.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.exceptions.EmployeeNotFoundException;
import com.cts.model.Employee;
import com.cts.repository.EmployeeRepository;
@Service
public class EmployeeServiceImpl  implements EmployeeService {

	@Autowired
	
	private EmployeeRepository employeeRepository;
	
	@Override
	public List<Employee> getAll() {
		// TODO Auto-generated method stub
		return employeeRepository.findAll();
	}

	@Override
	public Employee getById(int id) {
		// TODO Auto-generated method stub
		return employeeRepository.findById(id)
				.orElseThrow(()->new EmployeeNotFoundException
						("Employee with the ID "+id+" not found"));
	}

	@Override
	public String addEmployee(Employee employee) {
		employeeRepository.save(employee);
		return "Employee with id "+employee.getId()+" saved successfully";
	}

	@Override
	public String updateEmployee(int id, Employee employee) {
		Optional<Employee> optEmployee=employeeRepository.findById(id);
		if(!optEmployee.isPresent()) {
			throw new EmployeeNotFoundException("Employee with the ID "+id+" not found");
		}
		Employee emp=optEmployee.get();
		if(employee.getName()!=null) {
			emp.setName(employee.getName());
		}
		if(employee.getGender()!=null) {
			emp.setGender(employee.getGender());
		}
		if(employee.getAge()!=0) {
			emp.setAge(employee.getAge());
		}
		if(employee.getSalary()!=0) {
			emp.setSalary(employee.getSalary());
		}
		
		employeeRepository.save(emp);
		return "Employee with id "+id+" updated successfully";
	}

	@Override
	public String deleteEmployee(int id) {
		Optional<Employee> optEmployee=employeeRepository.findById(id);
		if(!optEmployee.isPresent()) {
			throw new EmployeeNotFoundException("Employee with the ID "+id+" not found");
		}
		employeeRepository.deleteById(id);
		return "Employee with id "+id+" deleted successfully";
	}

}
