package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.Employee;
import com.cts.service.EmployeeService;

import jakarta.annotation.PostConstruct;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

	
	@Autowired
	private EmployeeService employeeService;
	@GetMapping
	public List<Employee> get(){
		return employeeService.getAll();
	}
	@GetMapping("/{id}")
	public Employee get(@PathVariable int id) {
		
		return employeeService.getById(id);
	}
	@PostMapping
	public String add(@RequestBody Employee employee) {
		return employeeService.addEmployee(employee);
	}
	@PutMapping("/{id}")
	public String update(@PathVariable int id,@RequestBody Employee employee) {
	
		return employeeService.updateEmployee(id, employee);
	}
	@DeleteMapping("/{id}")
	public String delete(@PathVariable int id) {
		return employeeService.deleteEmployee(id);
	}
	
}
