package org.reni.controller;

import java.util.List;

import org.reni.model.Employee;
import org.reni.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class EmployeeController {
	@Autowired
	private EmployeeService employeeService;

	@GetMapping("/")
	public String showIndexPage(Model model) {
		
		List<Employee> employees=employeeService.getAllEmployees();
		model.addAttribute("employees", employees);
		
		return "index";
	}
	@GetMapping("/add")
	public String showAddForm(Model model) {
		
		model.addAttribute("employee",new Employee());
		
		return "add";
	}
//	@RequestMapping(value = "/add-employee",method = RequestMethod.POST)
	@PostMapping("/add-employee")
	public String addEmployee(@ModelAttribute Employee employee) {
		
		employeeService.saveEmployee(employee);
		
		return "redirect:/";
		
	}
	@GetMapping("/update")
	public String showUpdateForm(Model model,int id) {
		
		Employee employee=employeeService.getEmployeeById(id);
		model.addAttribute("employee", employee);
		
		return "update";
	}
	@GetMapping("/delete")
	public String delete(int id) {
		
		employeeService.deleteEmployee(id);
		return "redirect:/";
		
	}
	@GetMapping("/get-by-gender")
	public String getByGender(String gender,Model model) {
		
		List<Employee> employees=employeeService.getEmployeeByGender(gender);
		
		model.addAttribute("employees", employees);
		return "index";
		
	}
	@GetMapping("/get-by-salary")
	public String getBySalary(double lower,double upper,Model model) {
		
		List<Employee> employees=employeeService.getBySalary(lower, upper);
		model.addAttribute("employees", employees);
		return "index";
		
	}
}
