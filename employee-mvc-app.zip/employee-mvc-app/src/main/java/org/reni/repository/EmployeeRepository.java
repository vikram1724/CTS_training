package org.reni.repository;

import java.util.List;

import org.reni.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface EmployeeRepository extends JpaRepository<Employee,Integer> {

	@Query("from Employee where gender=:gen")
	List<Employee> abcd(@Param("gen") String gender);
	List<Employee> findBySalaryBetween(double lower,double upper);
	
}
