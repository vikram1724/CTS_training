package org.reni.service;

import java.util.List;

import org.reni.model.Employee;

public interface EmployeeService {

	List<Employee> getAllEmployees();

	Employee getEmployeeById(int id);

	void saveEmployee(Employee employee);

	void deleteEmployee(int id);
	
	List<Employee> getEmployeeByGender(String gender);
	
	List<Employee> getBySalary(double lower,double upper);

}