package com.cts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.cts.dtos.JwtAuthResponse;
import com.cts.dtos.LoginDto;
import com.cts.security.JwtTokenProvider;

@Service
public class AuthServiceImpl implements AuthService {
	@Autowired
	private JwtTokenProvider jwtTokenProvider;
	
	private AuthenticationManager authenticationManager;
	

	public AuthServiceImpl(AuthenticationManager authenticationManager) {
		super();
		this.authenticationManager = authenticationManager;
	}


	@Override
	public JwtAuthResponse login(LoginDto loginDto) {
		
		UsernamePasswordAuthenticationToken authenticationToken=
				new UsernamePasswordAuthenticationToken(loginDto.getUsernameOrEmail(), loginDto.getPassword());
		
		Authentication authentication= authenticationManager.authenticate(authenticationToken);
		
		SecurityContextHolder.getContext().setAuthentication(authentication);
		
		String token=jwtTokenProvider.generateToken(authentication);
		JwtAuthResponse response=new JwtAuthResponse();
		response.setJwtToken(token);
		
		return response;
	}

}
