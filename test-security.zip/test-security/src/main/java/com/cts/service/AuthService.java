package com.cts.service;

import com.cts.dtos.JwtAuthResponse;
import com.cts.dtos.LoginDto;

public interface AuthService {

	JwtAuthResponse login(LoginDto loginDto);
}
