package com.cts.dtos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter

public class JwtAuthResponse {
	@Setter
	private String jwtToken;
	private String tokenType="Bearer";
}
