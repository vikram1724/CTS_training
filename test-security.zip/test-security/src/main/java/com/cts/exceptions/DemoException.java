package com.cts.exceptions;

import org.springframework.http.HttpStatus;

import lombok.Getter;
@Getter
public class DemoException extends RuntimeException {

	private HttpStatus status;
	private String message;
	public DemoException(HttpStatus status, String message) {
		
		this.status = status;
		this.message = message;
	}
	
	
}
