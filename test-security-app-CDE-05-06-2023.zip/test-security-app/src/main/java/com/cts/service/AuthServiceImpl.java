package com.cts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.cts.dtos.LoginDto;
import com.cts.security.JwtTokenProvider;
@Service
public class AuthServiceImpl implements AuthService {
	
	@Autowired
	private JwtTokenProvider jwtTokenProvider;

	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Override
	public String login(LoginDto loginDto) {
		
		UsernamePasswordAuthenticationToken token
			=new UsernamePasswordAuthenticationToken
			(loginDto.getUsernameOrEmail(), loginDto.getPassword());
		
		 Authentication authentication= authenticationManager.authenticate(token);
		 
		 SecurityContextHolder.getContext().setAuthentication(authentication);
		
		 
		return jwtTokenProvider.generateToken(authentication);
	}

}
