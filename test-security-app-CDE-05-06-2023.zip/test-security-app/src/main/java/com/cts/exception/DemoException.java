package com.cts.exception;

import org.springframework.http.HttpStatus;

import lombok.Getter;

public class DemoException extends RuntimeException {

	@Getter
	private HttpStatus status;
	@Getter
	private String message;
	public DemoException(HttpStatus status, String message) {
		
		this.status = status;
		this.message = message;
	}
	
	
}
